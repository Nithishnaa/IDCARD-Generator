# ID Card Generator
Generates a set of vertical/agenda ID cards to print out for events based on given parameters.

Only works with Chrome and with 3"x4" sizes.